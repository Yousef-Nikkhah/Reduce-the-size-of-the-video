from tkinter import Tk
from tkinter.filedialog import askopenfilename
import moviepy.editor as mp

# Function to compress video
def compress_video(file_path, output_path):
    video = mp.VideoFileClip(file_path)
    compressed_video = video.resize(height=360)
    compressed_video.write_videofile(output_path)

# Create tkinter window
root = Tk()
root.withdraw()

# Show file selection dialog
file_path = askopenfilename(title='انتخاب فایل ویدیو', filetypes=[('Video Files', '*.mp4')])

if file_path:
    # Set output directory
    output_directory = 'file_path, output_path'
    output_path = output_directory + 'output.mp4'

    # Compress video and save in the specified directory
    compress_video(file_path, output_path)
    print('Done')