Hello. I have written a code to compress high-sized videos, which tries to reduce the video size as much as possible. I tested my code with a 100 MB video and it successfully compressed it to 7 MB.

Please note that for the code to work correctly, you need the following libraries and programs installed:

- Python
- moviepy library
- mp library

To install the required packages, you can use the following commands:

pip install moviepy
pip install mp

I wish you success with your project.